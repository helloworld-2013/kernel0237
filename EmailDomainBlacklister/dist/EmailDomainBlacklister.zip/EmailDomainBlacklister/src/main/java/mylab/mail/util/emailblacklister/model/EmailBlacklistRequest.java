package mylab.mail.util.emailblacklister.model;

/**
 * Created by kernel0237 on 10/22/14.
 */
public class EmailBlacklistRequest {

    private EmailBlacklistForm emailBlacklistForm;

    public EmailBlacklistForm getEmailBlacklistForm() {
        return emailBlacklistForm;
    }

    public void setEmailBlacklistForm(EmailBlacklistForm emailBlacklistForm) {
        this.emailBlacklistForm = emailBlacklistForm;
    }
}
